@@include('../js/functions.js', {}); 
